package hxm.com.mobilesafe;

import android.content.Intent;
import android.os.Bundle;

import android.widget.Toast;

public class SetGuideActivity4 extends GeneralGuideActivity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_setguide4);
		
		
	}

	@Override
	public void showPrev() {
		// TODO Auto-generated method stub
		Intent intent = new Intent(this, SetGuideActivity3.class);
		startActivity(intent);
		finish();
		overridePendingTransition(R.anim.transtlate_prev_in, R.anim.transtlate_prev_out);

	}

	@Override
	public void showNext() {
		// TODO Auto-generated method stub
		finish();
		overridePendingTransition(R.anim.transtlate_next_in, R.anim.transtlate_next_out);
		Toast.makeText(this, "设置完成", 0).show();
	}
}
