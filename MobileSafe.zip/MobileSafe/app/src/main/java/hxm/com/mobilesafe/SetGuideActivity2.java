package hxm.com.mobilesafe;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.view.View;
import hxm.com.mobilesafe.ui.SettingItemView;


public class SetGuideActivity2 extends GeneralGuideActivity {
	private SettingItemView bindSim_v ;
	private SharedPreferences sp;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_setguide2);

		//得到sharePreferences
		sp = getSharedPreferences("config", MODE_PRIVATE);

		bindSim_v = findViewById(R.id.sim);
		boolean simb = sp.getBoolean("simbind",false);
		if(simb){
			bindSim_v.setChecked(true);
		}else{
			bindSim_v.setChecked(false);
		}
		bindSim_v.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Editor  editor = sp.edit();
				if(bindSim_v.isChecked()){
					bindSim_v.setChecked(false);
					bindSim_v.setContent("SIM卡未绑定");
					editor.putBoolean("simbind", false);
				}else{
					bindSim_v.setChecked(true);
					bindSim_v.setContent("SIM卡已经绑定");
					editor.putBoolean("simbind", true);
				}
				editor.commit();
			}
		});
	}

	@Override
	public void showPrev() {
		// TODO Auto-generated method stub
		Intent intent = new Intent(this, SetGuideActivity1.class);
		startActivity(intent);
		finish();
		overridePendingTransition(R.anim.transtlate_prev_in, R.anim.transtlate_prev_out);
	}

	@Override
	public void showNext() {
		// TODO Auto-generated method stub
		Intent intent = new Intent(this, SetGuideActivity3.class);
		startActivity(intent);
		finish();
		overridePendingTransition(R.anim.transtlate_next_in, R.anim.transtlate_next_out);

	}
}
